import React from 'react'
import './OurTeam.css'
const OurTeam = () => {
  return (
    <div className="sopand">
      <h1 style={{textAlign:"center"}}>Our Team</h1>
      <div class="card">
  <img src="./image\billgates.jpg"alt="Avatar" style={{width:"100%"}}/>
  <div class="container1">
    <h4><b style={{fontSize:"20px"}}>Bill Gates</b></h4> 
    <p>SDE1</p> 
  </div>
  <img src="\image\adii.jpg" alt="adii" style={{width:"100%"}}/>
  <div class="container1">
    <h4><b style={{fontSize:"20px"}}>Aditya Raghuwanshi</b></h4> 
    <p>CEO</p> </div>
   < img src=".\image\danish.jpg"alt="Danii" style={{width:"100%"}}/>
  <div class="container1">
    <h4><b style={{fontSize:"20px"}}>Danish Singhal</b></h4> 
    <p>CTO</p> 
  </div>
 < img src=".\image\adii2.jpeg"alt="adii2" style={{width:"100%"}}/>
  <div class="container1">
    <h4><b style={{fontSize:"20px"}}>Adii 2</b></h4> 
    <p>Founder</p> 
  </div>
</div>


<div className='container'>
      <div className="info">
        <p>Revolutionize The Tech-Learning Space With Us.</p>
        We are always eager to discuss fresh ideas. Check out our open positions!
        <button  className='join'>Join Kalvium</button>

        </div>
        
    </div>
    <div className="last">
        Dear parents and students, be vigilant while making your fee payments.
       
        </div>
    </div>
  )
}

export default OurTeam
