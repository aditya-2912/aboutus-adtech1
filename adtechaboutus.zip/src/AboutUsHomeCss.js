import { makeStyles } from "@mui/styles";
//import { height } from "@mui/system";
export const useStyles=makeStyles({
    mainContainer:{
       // display:'flex',
        paddingLeft:'0%',
        //background:'#ecf0f1',
        width:'100%',
        height:'300px',
       backgroundColor:'#F9EFDB',
        backgroundImage:"url(https://kalvium.com/wp-content/uploads/2023/04/Grids-Bg-full.svg)",padding:20,
        position:'relative',

        
    },

})