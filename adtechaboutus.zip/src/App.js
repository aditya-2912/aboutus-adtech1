import AboutUs from "./AboutUs/AboutUs";
import AboutUsHome from "./AboutUsHome";
import './App.css';
import OurTeam from "./OurTeam/OurTeam";

function App() {
  return (
    <>
    <AboutUsHome/>
   <AboutUs/>
   <OurTeam/>
   
   </>
  );
}

export default App;
