import React from 'react'
import{ useStyles} from"./AboutUsHomeCss"  
const AboutUsHome = () => {
    const classes = useStyles()
  return (
    <div>
        <div className={classes.mainContainer}>
            <div className='text'>
              <p style={{textAlign:"center"}}>KALVIUM</p>
             <p style={{textAlign:"center",color:"grey"}}>/ kalʋi-əm /</p><p style={{textAlign:"center",fontSize:"20px"}}>
[Re-imagining] – Academia; [Re-imagining] – Education
</p>
            </div>
        </div>
      
    </div>
  )
}

export default AboutUsHome
