import React from 'react'
import './AboutUs.css';

const AboutUs = () => {
  return (

    <div className='vison'>
         <div className='content'>   </div> 
    <img src= "./image/vision.png" alt=""style={{ width: '400px', height: 'auto' }}/>
    <div className='content'>
      <h1>Our Vision</h1>
     <p style={{fontSize:"15px"}}>Our vision is to challenge and transform the undergraduate engineering learning space by introducing a truly experiential leading-edge curriculum that will help meritorious students achieve their career aspirations in the tech world.</p>

    </div>
 


    </div>
  )
}

export default AboutUs
